package com.game.source.engine;

import org.lwjgl.input.Mouse;

public class GameTick { // Calculate all that happens in the game
	
	public static void run(int delta) {
		Input.update();
		
		Camera.rotateCam((float) (Mouse.getDX() * 0.1), (float) (Mouse.getDY() * -0.1));
		
		RenderTick.rotx = 0;
		RenderTick.roty = 0;
		RenderTick.movx = 0;
		RenderTick.movy = 0;
		RenderTick.movz = 0;
		/*
		if (Input.getKey(205)) {
			RenderTick.rotx = (float) 0.3 * delta;
		}
		if (Input.getKey(203)) {
			RenderTick.rotx = (float) -0.3 * delta;
		}
		if (Input.getKey(200)) {
			RenderTick.roty = (float) 0.3 * delta;
		}
		if (Input.getKey(208)) {
			RenderTick.roty = (float) -0.3 * delta;
			System.out.println(RenderTick.roty);
		} // WASD : 17, 30, 31, 32  QE : 16, 18
		*/
		float speed = 0.02f;
		if (Input.getKey(17)) {
			Camera.move(speed * delta, 0f, 0f);
		}
		if (Input.getKey(30)) {
			Camera.move(0f, -speed * delta, 0f);
		}
		if (Input.getKey(31)) {
			Camera.move(-speed * delta, 0f, 0f);
		}
		if (Input.getKey(32)) {
			Camera.move(0f, speed * delta, 0f);
		}
		if (Input.getKey(16)) {
			Camera.move(0f, 0f, speed * delta);
		}
		if (Input.getKey(18) && RenderTick.movy > -3) {
			Camera.move(0f, 0f, -speed * delta);
		}
	}
}
