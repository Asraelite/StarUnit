package com.game.source.engine;

import static org.lwjgl.opengl.GL11.*; // Import OpenGL

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;

public class RenderTick { // Calculate all that needs to be rendered
	public static float rotx = 0;
	public static float roty = 0;
	public static float movx = 0;
	public static float movy = 0;
	public static float movz = 0;
	public static int x = 300;
	public static int y = 200;
	public static Texture texture = null;

	public static void setup() {
		glTranslatef(-1.25f, 1.25f, -10f); // Move 10 out
		
		try {
			texture = TextureLoader.getTexture("JPG", new FileInputStream(new File("src/face.jpg")));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	private static int seed(int in) {
		return (((in * 467) % 43) * 79203) % 255;
	}

	private static void drawCube(float size, float x, float y, float z) { // My function I made by myself :3
		int[] offset = new int[] {
				0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, // XY Face "Front"
				0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, // YZ Face "Left"
				0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, // ZX Face "Bottom"
				0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, // XY Face "Back"
				1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, // YZ Face "Right"
				0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0 // ZX Face "Top"

		}; // This shortens 24 of code lines into 6
		
		float[][] colors = new float[][] { { 0.2f, 0.2f, 0.5f }, { 0.5f, 0.2f, 0.5f }, { 0.5f, 0.2f, 0.2f },
				{ 0.5f, 0.5f, 0.2f }, { 0.2f, 0.5f, 0.5f }, { 0, 2f, 0.5f, 0.2f } };
		
		int[] texCoords = new int[] { 0, 1, 0, 0, 1, 0, 1, 1 };
		
		int i = 0;

		glBindTexture(GL_TEXTURE_2D, texture.getTextureID()); // Set texture as current one being used

		glBegin(GL_QUADS); // start draw faces
		while (i < 72) {
			int index = (int) Math.floor(i / 12);
			//glColor3f(colors[index][0], colors[index][1], colors[index][2]); // Colour
			glVertex3f(x + ((size / 2) * offset[i]), y + ((size / 2) * offset[i + 1]), z + ((size / 2) * offset[i + 2]));
			int ti = ((i % 12) / 3) * 2;
			glTexCoord2f(texCoords[ti], texCoords[ti + 1]);
			i += 3;
		}
		
		glBindTexture(GL_TEXTURE_2D, 0);
		glEnd(); // End draw quad
	}

	public static void run() {
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Clear

		//glTranslatef(x + 100, y + 100, 0);
		//glRotatef(roty, 1f, 0f, 0f);
		//glRotatef(rotx, 0f, 1f, 0f);
		//glTranslatef(movx, movy, movz);
		//glRotatef(0, 0f, 0f, 1f);
		//glTranslatef(-x - 100, -y - 100, 0);

		Camera.camLookThrough();

		drawCube(5f, 0f, -2.5f, -2.5f); // f makes it a float
	}
	
	public static void end(){
		texture.release(); // You have served your purpose, now go! Be free!
	}
}
