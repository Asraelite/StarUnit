package com.game.source.engine;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.*;
import org.lwjgl.util.glu.GLU;

import com.game.source.engine.Window;

public class Frame { // Handles frame rate management (not faster than 60 etc.)
	public static final double FRAME_CAP = 60.0;

	private static void initGL() {
		GL11.glEnable(GL11.GL_TEXTURE_2D); // Enable Texture Mapping
		GL11.glShadeModel(GL11.GL_SMOOTH); // Enable Smooth Shading
		GL11.glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Black Background
		GL11.glClearDepth(1.0); // Depth Buffer Setup
		GL11.glEnable(GL11.GL_DEPTH_TEST); // Enables Depth Testing
		GL11.glDepthFunc(GL11.GL_LEQUAL); // The Type Of Depth Testing To Do

		GL11.glMatrixMode(GL11.GL_PROJECTION); // start OpenGL
		GL11.glLoadIdentity();

		GLU.gluPerspective(45.0f, (float) 1000 / (float) 650, 0.1f, 100.0f);
		GL11.glMatrixMode(GL11.GL_MODELVIEW); // Select The Model view Matrix, whatever that is

		GL11.glHint(GL11.GL_PERSPECTIVE_CORRECTION_HINT, GL11.GL_NICEST); // Perspective calculations or something
	}

	public static void start() {
		Window window = new Window();
		
		Camera.setCamPos(0, 0, -5);
		initGL();
		RenderTick.setup();
		
		Mouse.setGrabbed(true); // Lock mouse

		while (!window.isCloseRequested() && !Input.getKey(1)){
			long thisTime = Clock.getTime();
			int delta = (int) ((thisTime - Clock.getLastTime()) / 1000000);
			Clock.setLastTime(thisTime);
			GameTick.run(delta);
			RenderTick.run();
			GL11.glLoadIdentity();
			window.updateDisplay();
			Display.sync(60);
		}
		
		RenderTick.end();
		window.endDisplay();
	}
}
